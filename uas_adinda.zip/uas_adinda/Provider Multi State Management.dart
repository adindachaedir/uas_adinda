import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

void main() => runApp(MyApp());

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home : Scaffold(
        floatingActionButton: FloatingActionButton(onPressed: (),{}, child: Icon(Icon.add_shopping_cart),),
        appBar: AppBar(backgroundColor : Colors.purple, title: Text("Provider Multi State Management"),),
        ),
        body: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: <Widget>[
               Row (
                mainAxisAlignment: MainAxisAlignment.center ,
                children: <Widget>[
                  text("Balance"),
                  Container(
                    child: Align(
                      Aligment.centerRight,
                      child: Text ("Apple (500) x 20 ",style: TextStyle (color:Colors.black, fontWeight: FontWeight.w700))
                    ),
                    height: 30,
                    width: 150,
                    margin :EdgeInsets.all(5),
                    padding: EdgeInsets.all(5),
                    decoration: BoxDecoration(
                      color:Colors.purple[100],
                      border: Border.all(color: Colors.purple, width: 2)),
                  )
                ],
              ),
              Container(
                    child: Align(
                      Aligment.centerRight,
                      child: Row(
                       
                         Text ("10000",style: TextStyle (color:Colors.purple, fontWeight: FontWeight.w700)),
                        ],
                      )
                    ),
                    height: 30,
                    margin :EdgeInsets.all(5),
                    padding: EdgeInsets.all(5),
                    decoration: BoxDecoration(
                      border: Border.all(color: Colors.black, width: 2)),
                  )
            ],
          ),
        ),
      ),
    );
  }
}

