//source API http://api.bengkelrobot.net:8001/api/profile

// REST API GET
{
  {
    "id" : 1,
    "name ": "user",
    "email":"user@gmail.com",
    "age":21
  }
  {
    "id" : 2,
    "name ": "Bob",
    "email":"bob@gmail.com",
    "age":21
  }
}

//REST API POST
{
  "name" : "Merlyn",
  "email": "merlyn@gmail.com",
  "age":28
}

//REST API PUT
{
  {
  "name" : "Merlyn Edit",
  "email": "merlyn@gmail.com",
  "age":28
}
}

//REST API DELETE
{
  "message " : "Delete Success"
}